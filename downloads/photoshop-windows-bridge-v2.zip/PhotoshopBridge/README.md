# Windows Photoshop 2023 云端连接器

本机运行 PowerShell 连接器，通过 Photoshop 的 Windows COM / ExtendScript 接口执行任务；Cloudflare 临时隧道提供 HTTPS 地址。云端客户端带访问口令调用该地址。本机端口只绑定 127.0.0.1，无需修改路由器端口映射或安装 Python。

## 本机操作

1. 下载并解压 `photoshop-windows-bridge.zip`。如果 Windows 给下载文件添加了锁定标记，在确认来源和检查脚本后，在 ZIP 的“属性”中选择“解除锁定”，再解压。
2. 以普通用户权限打开 **Windows x64 Photoshop 2023**，关闭所有模态对话框；连接器也以同一用户的普通权限运行。首次连接检查可不打开图片。用户已在 Windows PowerShell STA 模式下用 `Photoshop.Application.170` 验证脚本执行成功，返回版本 24.0.1；当前连接器使用该接口。
3. 双击解压目录中的 `Run.cmd`。它使用 Windows PowerShell 的 STA 模式，执行策略仅对该进程设为 RemoteSigned，不改变系统设置。
4. 首次运行会从 Cloudflare 官方 GitHub Release 下载 `cloudflared` 2026.10.3，并核对发布页提供的 SHA-256；校验失败会停止。需要能访问 GitHub 下载和 Cloudflare 隧道服务，后者可能使用 TCP 7844；企业网络限制时请使用管理员批准的网络方案。
5. 本机窗口会显示 `PS_BRIDGE_URL` 和一个临时口令。**只把 HTTPS 地址发给 Codex，口令不要发到聊天中。**地址确认后，Codex 会为该确切域名声明密钥要求；再把口令输入云环境设置的安全密钥输入框。
6. 保持窗口开启。关闭窗口或按 Ctrl+C 即断开。临时地址和口令在每次启动后变化，需要更新配置；要长期固定地址，应另行配置你自己的稳定隧道。

此方案需要用户在本机运行连接器，云端不能代替用户启动本机 Photoshop。没有安装 Photoshop 插件，不依赖旧版 Photoshop Remote Connections TCP 协议。

## 云端命令

在环境设置中配置非秘密变量 `PS_BRIDGE_URL`，并将密钥 `PS_BRIDGE_TOKEN` 绑定到该地址的确切 HTTPS 域名。复用现有绑定；不要把口令写进源码、命令行参数或聊天。

```bash
cd /workspace/ecommerce-studio
source env.sh
python photoshop/cloud/ps_client.py status
```

连接成功会返回 Photoshop 版本、打开文档数量，以及当前文档的名称和尺寸。只有真实返回这些信息，才算连接验证完成。

在用户要求导出时执行，例如：

```bash
python photoshop/cloud/ps_client.py export --name SKU123_en_v01 --format jpg --width 2000 --height 2000
python photoshop/cloud/ps_client.py download --name SKU123_en_v01.jpg
```

导出会复制当前文档、转为 8 位 sRGB，并等比例缩放到给定尺寸范围内，然后保存副本；原始文档不保存、不覆盖。参数不表示填满指定尺寸的方形画布。例如 3000×1500 输入会导出 2000×1000。JPG 使用 Photoshop 的 0–12 质量范围；PNG 保留可用透明度。导出到本机“文档/ECommerceStudio/exports”，同名文件拒绝覆盖。云端仅可下载本次连接器会话生成的 JPG/PNG，最大 100 MiB。下载后仍须检查实际商品外观与导出内容。

当前白名单接口：读取状态、导出当前文档副本、取回本次会话导出图。任意 JSX 执行、读取本机任意路径、上传 PSD、替换图层和批量文案不在首版接口中；需要时单独增加并验证。此文档不承诺 JPEG 透明区域的底色，主图要求纯白时需另行明确处理方式。

## 状态与排障

- 当前 Linux 云机没有 Photoshop；云端测试不能证明本机 PS 或隧道已连接。
- 401：检查该次启动的口令和精确域名绑定，不在聊天中传递口令。
- 503：检查 PS 是否打开、是否有对话框、COM 是否注册。官方安装的 Photoshop 通常注册 `Photoshop.Application`；不要未经诊断修改注册表或重装软件。
- Windows `0x80080005 / CO_E_SERVER_EXEC_FAILURE`：通用接口此前在用户机器失败；检查发现实际路径与注册路径一致，都是 PS 2023，PowerShell 为 64 位。改为 PS 与 PowerShell 均以普通权限启动，PowerShell 使用 STA、调用 `Photoshop.Application.170` 后，用户报告脚本执行成功，版本 24.0.1。成功所需各因素尚未分别隔离；沿用整个已验证的启动方式。旧包不含接口修正，应使用 v2。
- 隧道启动失败：查看连接器 `bin/tunnel-*.log`。如果本机已有 Cloudflare 配置影响临时隧道，保留原配置并单独排查，不要删除用户配置。
- 导出后请求超时：先检查本机交付目录，避免盲目重试。同名文件不会被覆盖。

本机窗口所显示的口令仅留在本次进程内存中，不写入日志或脚本。临时地址本身不能代替口令验证；所有业务接口都要求 Bearer 验证。不要把本机窗口含口令的截图发到聊天。
